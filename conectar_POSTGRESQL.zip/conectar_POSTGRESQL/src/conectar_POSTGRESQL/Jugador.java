package conectar_POSTGRESQL;

public class Jugador {
	
	private String nombre;
	private String equipo;
	
	
	
	public Jugador(String nombre, String posicion) {
		this.nombre = nombre;
		this.equipo = posicion;
	}
	
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getPosicion() {
		return equipo;
	}
	public void setPosicion(String posicion) {
		this.equipo = posicion;
	}

}
